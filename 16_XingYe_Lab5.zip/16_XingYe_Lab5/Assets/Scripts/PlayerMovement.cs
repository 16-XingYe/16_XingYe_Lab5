﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{

    public float speed;
    public Rigidbody RB;
    public Text CoinText;
    int Coins;
    
    void Update()
    {
        Coins = GameObject.FindGameObjectsWithTag("Coin").Length;
        CoinText.text = "Coins Left: " + Coins;
        
        if (Coins == 0)
        {
            SceneManager.LoadScene("GameWin");
        }

    }

    
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        RB.AddForce(movement * speed * Time.deltaTime);

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coin")
        {
            Destroy(collision.gameObject);

        }

        else if (collision.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("GameLose");
        }
    }
}
